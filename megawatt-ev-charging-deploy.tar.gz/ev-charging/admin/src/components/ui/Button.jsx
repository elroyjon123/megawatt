import { cn } from "../../lib/cn";

const VARIANT = {
  primary: "bg-emerald-600 text-white hover:bg-emerald-700 active:bg-emerald-800",
  secondary:
    "bg-white text-slate-800 border border-slate-200 hover:bg-slate-50 " +
    "dark:bg-slate-900/50 dark:text-slate-100 dark:border-slate-700 dark:hover:bg-slate-900/70",
  ghost: "bg-transparent text-slate-700 hover:bg-slate-100/70 dark:text-slate-200 dark:hover:bg-slate-800/60",
  danger: "bg-rose-600 text-white hover:bg-rose-700 active:bg-rose-800",
};

const SIZE = {
  sm: "h-9 px-3 text-sm",
  md: "h-10 px-4 text-sm",
  lg: "h-11 px-5 text-sm",
};

export default function Button({
  as: Comp = "button",
  variant = "primary",
  size = "md",
  className,
  ...props
}) {
  return (
    <Comp
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl font-semibold shadow-sm transition",
        "disabled:pointer-events-none disabled:opacity-50",
        VARIANT[variant] || VARIANT.primary,
        SIZE[size] || SIZE.md,
        className
      )}
      {...props}
    />
  );
}
