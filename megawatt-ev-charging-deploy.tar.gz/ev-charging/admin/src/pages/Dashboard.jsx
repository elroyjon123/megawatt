import { useQuery } from "react-query";
import axios from "axios";
import { Link } from "react-router-dom";
import { Suspense, lazy, useMemo } from "react";
import Card, { CardBody } from "../components/ui/Card";
import Skeleton from "../components/ui/Skeleton";
import ErrorState from "../components/ui/ErrorState";

const StatusPieChart = lazy(() => import("../components/dashboard/StatusPieChart"));
const RevenueLineChart = lazy(() => import("../components/dashboard/RevenueLineChart"));
const OcppServerStatusCard = lazy(() => import("../components/dashboard/OcppServerStatusCard"));

const fetchSummary = async () => {
  const response = await axios.get(`${import.meta.env.VITE_API_URL}/admin/dashboard/summary`);
  return response.data;
};

function KpiCard({ label, value }) {
  return (
    <Card className="bg-white/70">
      <CardBody className="px-5 py-4">
        <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</div>
        <div className="mt-2 text-2xl font-semibold tracking-tight text-slate-900">{value}</div>
      </CardBody>
    </Card>
  );
}

export default function Dashboard() {
  const { data, isLoading, error } = useQuery(["dashboardSummary"], fetchSummary, {
    refetchInterval: 30_000,
  });

  // IMPORTANT: hooks must run on every render. Keep derived-state hooks above early returns.
  const kpis = data?.kpis ?? {};
  const status = data?.statusOverview ?? {};
  const recentSessions = data?.recentSessions ?? [];
  const revenueLast7Days = data?.revenueLast7Days ?? [];

  const statusChartData = useMemo(
    () =>
      Object.entries(status).map(([name, value]) => ({
        name,
        value: Number(value || 0),
      })),
    [status]
  );

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="bg-white/70">
              <CardBody className="px-5 py-4">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="mt-3 h-8 w-16" />
              </CardBody>
            </Card>
          ))}
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="bg-white/70">
            <CardBody>
              <Skeleton className="h-5 w-44" />
              <Skeleton className="mt-4 h-64 w-full" />
            </CardBody>
          </Card>
          <Card className="bg-white/70">
            <CardBody>
              <Skeleton className="h-5 w-44" />
              <Skeleton className="mt-4 h-64 w-full" />
            </CardBody>
          </Card>
        </div>
      </div>
    );
  }
  if (error) {
    return (
      <ErrorState
        title="Failed to load dashboard"
        description={error?.response?.data?.error || error?.message}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-5">
        <KpiCard label="Total Chargers" value={kpis.totalChargers ?? 0} />
        <KpiCard label="Active Chargers" value={kpis.activeChargers ?? 0} />
        <KpiCard label="Active Sessions" value={kpis.activeSessions ?? 0} />
        <KpiCard label="Revenue Today" value={`₱ ${kpis.revenueToday ?? 0}`} />
        <KpiCard label="Total Users" value={kpis.totalUsers ?? 0} />
      </div>

      <Suspense fallback={null}>
        <OcppServerStatusCard />
      </Suspense>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="bg-white/70">
          <CardBody>
            <h2 className="text-base font-semibold text-slate-900">Revenue (last 7 days)</h2>

            <Suspense
              fallback={<div className="mt-4 rounded-xl border border-slate-200 bg-white/60 p-4 text-sm text-slate-600">Loading chart…</div>}
            >
              <div className="mt-4 min-h-[240px] rounded-xl border border-slate-200 bg-white/60">
                <RevenueLineChart data={revenueLast7Days} />
              </div>
            </Suspense>
          </CardBody>
        </Card>

        <Card className="bg-white/70">
          <CardBody>
            <h2 className="text-base font-semibold text-slate-900">Recent sessions</h2>
          {recentSessions.length === 0 ? (
            <p className="mt-3 text-sm text-slate-600">No sessions yet.</p>
          ) : (
            <div className="mt-4 overflow-auto rounded-xl border border-slate-200 bg-white/60">
              <table className="w-full text-left text-sm">
                <thead className="bg-white/70 text-xs uppercase text-slate-500">
                  <tr>
                    <th className="px-3 py-2">Station</th>
                    <th className="px-3 py-2">Charger</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Start</th>
                    <th className="px-3 py-2">kWh</th>
                    <th className="px-3 py-2">Cost</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentSessions.map((s) => (
                    <tr key={s.id} className="text-slate-700">
                      <td className="px-3 py-2 pr-3">{s.charger?.station?.name ?? "-"}</td>
                      <td className="px-3 py-2 pr-3">
                        {s.charger?.id ? (
                          <Link to={`/chargers/${s.charger.id}`} className="text-slate-900 underline decoration-emerald-400/60 underline-offset-4">
                            {s.charger?.name ?? "-"}
                          </Link>
                        ) : (
                          s.charger?.name ?? "-"
                        )}
                      </td>
                      <td className="px-3 py-2 pr-3">{s.status}</td>
                      <td className="px-3 py-2 pr-3">{new Date(s.startTime).toLocaleString()}</td>
                      <td className="px-3 py-2 pr-3">{s.energyKwh}</td>
                      <td className="px-3 py-2 pr-3">₱ {s.costPeso}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          </CardBody>
        </Card>

        <Card className="bg-white/70">
          <CardBody>
            <h2 className="text-base font-semibold text-slate-900">Charger status overview</h2>

          <Suspense
            fallback={
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                {Object.keys(status).length === 0 ? (
                  <p className="text-slate-600">No chargers found.</p>
                ) : (
                  Object.entries(status).map(([k, v]) => (
                    <div key={k} className="rounded-xl bg-white/60 p-3 ring-1 ring-slate-200">
                      <div className="text-xs font-semibold text-slate-500">{k}</div>
                      <div className="mt-1 text-xl font-semibold text-slate-900">{v}</div>
                    </div>
                  ))
                )}
              </div>
            }
          >
            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <div className="min-h-[240px] rounded-xl border border-slate-200 bg-white/60">
                <StatusPieChart data={statusChartData} />
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                {Object.keys(status).length === 0 ? (
                  <p className="text-slate-600">No chargers found.</p>
                ) : (
                  Object.entries(status).map(([k, v]) => (
                    <div key={k} className="rounded-xl bg-white/60 p-3 ring-1 ring-slate-200">
                      <div className="text-xs font-semibold text-slate-500">{k}</div>
                      <div className="mt-1 text-xl font-semibold text-slate-900">{v}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </Suspense>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
