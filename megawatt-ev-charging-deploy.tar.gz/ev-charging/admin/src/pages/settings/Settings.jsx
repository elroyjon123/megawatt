import { useEffect, useState } from "react";
import axios from "axios";

export default function Settings() {
  const [profile, setProfile] = useState({ name: "", phone: "" });
  const [passwords, setPasswords] = useState({ oldPassword: "", newPassword: "" });
  const [forwarding, setForwarding] = useState({
    internalBaseUrl: "",
    progressTargetUrl: "",
    alertTargetUrl: "",
    internalToken: "",
    internalTokenSet: false,
  });
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const devtoolsEnabled = Boolean(import.meta.env.VITE_DEVTOOLS_TOKEN);

  useEffect(() => {
    (async () => {
      try {
        const resp = await axios.get(`${import.meta.env.VITE_API_URL}/auth/me`);
        setProfile({ name: resp.data?.name || "", phone: resp.data?.phone || "" });

        // Load OCPP server forwarding config (Option A)
        try {
          const f = await axios.get(`${import.meta.env.VITE_API_URL}/admin/ocpp-server/forwarding`);
          setForwarding({
            internalBaseUrl: f.data?.internalBaseUrl || "",
            progressTargetUrl: f.data?.progressTargetUrl || "",
            alertTargetUrl: f.data?.alertTargetUrl || "",
            internalToken: "",
            internalTokenSet: !!f.data?.internalTokenSet,
          });
        } catch {
          // ignore: OCPP server may not support forwarding endpoint yet
        }
      } catch (err) {
        setError(err.response?.data?.error || "Failed to load profile");
      }
    })();
  }, []);

  const saveProfile = async (e) => {
    e.preventDefault();
    setMessage(null);
    setError(null);
    setSaving(true);
    try {
      await axios.put(`${import.meta.env.VITE_API_URL}/auth/me`, profile);
      setMessage("Profile updated");
    } catch (err) {
      setError(err.response?.data?.error || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    setMessage(null);
    setError(null);
    setSaving(true);
    try {
      await axios.put(`${import.meta.env.VITE_API_URL}/auth/password`, passwords);
      setMessage("Password updated");
      setPasswords({ oldPassword: "", newPassword: "" });
    } catch (err) {
      setError(err.response?.data?.error || "Failed to change password");
    } finally {
      setSaving(false);
    }
  };

  const saveForwarding = async (e) => {
    e.preventDefault();
    setMessage(null);
    setError(null);
    setSaving(true);
    try {
      // Allow break-glass config when DB/JWT login is unavailable
      const maint = import.meta.env.VITE_ADMIN_MAINTENANCE_TOKEN;
      if (maint) {
        axios.defaults.headers.common["X-Admin-Maintenance-Token"] = maint;
      }

      const payload = {
        ...(forwarding.internalBaseUrl ? { internalBaseUrl: forwarding.internalBaseUrl } : {}),
        ...(forwarding.progressTargetUrl ? { progressTargetUrl: forwarding.progressTargetUrl } : {}),
        ...(forwarding.alertTargetUrl ? { alertTargetUrl: forwarding.alertTargetUrl } : {}),
        ...(forwarding.internalToken ? { internalToken: forwarding.internalToken } : {}),
      };
      const resp = await axios.post(`${import.meta.env.VITE_API_URL}/admin/ocpp-server/forwarding`, payload);
      setForwarding((prev) => ({
        ...prev,
        internalBaseUrl: resp.data?.internalBaseUrl || prev.internalBaseUrl,
        progressTargetUrl: resp.data?.progressTargetUrl || prev.progressTargetUrl,
        alertTargetUrl: resp.data?.alertTargetUrl || prev.alertTargetUrl,
        internalToken: "",
        internalTokenSet: !!resp.data?.internalTokenSet,
      }));
      setMessage("OCPP forwarding updated");
    } catch (err) {
      setError(err.response?.data?.error || "Failed to update forwarding");
    } finally {
      setSaving(false);
    }
  };

  const emitTestAlert = async () => {
    setMessage(null);
    setError(null);
    try {
      await axios.post(
        `${import.meta.env.VITE_API_URL}/admin/devtools/emit-alert`,
        { title: "Test alert", description: "Hello from devtools", severity: "info" },
        { headers: { "X-Devtools-Token": import.meta.env.VITE_DEVTOOLS_TOKEN } }
      );
      setMessage("Test alert emitted. Check CPO Alerts page.");
    } catch (err) {
      setError(err.response?.data?.error || "Failed to emit alert");
    }
  };

  const emitTestSessionProgress = async () => {
    setMessage(null);
    setError(null);
    try {
      let sessionId = "dev-session-1";
      // Prefer a real session if the API/DB is available.
      try {
        const resp = await axios.get(`${import.meta.env.VITE_API_URL}/admin/sessions`, { params: { page: 1, pageSize: 1 } });
        const first = resp.data?.items?.[0];
        if (first?.id) sessionId = first.id;
      } catch {
        // ignore
      }

      await axios.post(
        `${import.meta.env.VITE_API_URL}/admin/devtools/emit-session-progress`,
        { sessionId, energyDelivered: 2.5, totalCost: 35.0, powerKw: 7.2 },
        { headers: { "X-Devtools-Token": import.meta.env.VITE_DEVTOOLS_TOKEN } }
      );

      setMessage(`Test session progress emitted for session ${sessionId}. Open /sessions/${sessionId}.`);
    } catch (err) {
      setError(err.response?.data?.error || "Failed to emit session progress");
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-white p-6 shadow-sm">
        <h1 className="text-xl font-semibold text-slate-900">Settings</h1>
        {message && <div className="mt-3 text-sm text-slate-700">{message}</div>}
        {error && <div className="mt-3 text-sm text-red-600">{error}</div>}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <h2 className="text-base font-semibold text-slate-900">Profile</h2>
          <form onSubmit={saveProfile} className="mt-4 space-y-3">
            <input
              value={profile.name}
              onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))}
              className="w-full rounded-lg border border-slate-200 p-3"
              placeholder="Name"
            />
            <input
              value={profile.phone}
              onChange={(e) => setProfile((p) => ({ ...p, phone: e.target.value }))}
              className="w-full rounded-lg border border-slate-200 p-3"
              placeholder="Phone"
            />
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-slate-900 px-5 py-3 text-sm font-semibold text-white disabled:opacity-60"
            >
              {saving ? "Saving..." : "Save profile"}
            </button>
          </form>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-sm">
          <h2 className="text-base font-semibold text-slate-900">Change password</h2>
          <form onSubmit={changePassword} className="mt-4 space-y-3">
            <input
              type="password"
              value={passwords.oldPassword}
              onChange={(e) => setPasswords((p) => ({ ...p, oldPassword: e.target.value }))}
              className="w-full rounded-lg border border-slate-200 p-3"
              placeholder="Old password"
            />
            <input
              type="password"
              value={passwords.newPassword}
              onChange={(e) => setPasswords((p) => ({ ...p, newPassword: e.target.value }))}
              className="w-full rounded-lg border border-slate-200 p-3"
              placeholder="New password (min 8 chars)"
            />
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg border border-slate-200 px-5 py-3 text-sm font-semibold disabled:opacity-60"
            >
              {saving ? "Saving..." : "Update password"}
            </button>
          </form>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-sm lg:col-span-2">
          <h2 className="text-base font-semibold text-slate-900">OCPP server forwarding (Option A)</h2>
          <p className="mt-2 text-sm text-slate-600">
            This config is saved on the external OCPP server via <code>/admin/forwarding</code> (proxied through this backend).
          </p>

          <form onSubmit={saveForwarding} className="mt-4 grid gap-3 lg:grid-cols-2">
            <div className="lg:col-span-2">
              <input
                value={forwarding.internalBaseUrl}
                onChange={(e) => setForwarding((p) => ({ ...p, internalBaseUrl: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 p-3"
                placeholder="Internal base URL (e.g. https://api.example.com/api/internal)"
              />
              <div className="mt-2 text-xs text-slate-500">
                Used by the OCPP VM to forward Boot/Heartbeat/Status/Start/Meter/Stop webhooks.
              </div>
            </div>
            <input
              value={forwarding.progressTargetUrl}
              onChange={(e) => setForwarding((p) => ({ ...p, progressTargetUrl: e.target.value }))}
              className="w-full rounded-lg border border-slate-200 p-3"
              placeholder="Session progress URL (e.g. https://api.example.com/api/internal/session/progress)"
            />
            <input
              value={forwarding.alertTargetUrl}
              onChange={(e) => setForwarding((p) => ({ ...p, alertTargetUrl: e.target.value }))}
              className="w-full rounded-lg border border-slate-200 p-3"
              placeholder="CPO alert URL (e.g. https://api.example.com/api/internal/cpo/alert)"
            />
            <div className="lg:col-span-2">
              <input
                value={forwarding.internalToken}
                onChange={(e) => setForwarding((p) => ({ ...p, internalToken: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 p-3"
                placeholder={forwarding.internalTokenSet ? "Internal token is set (enter to overwrite)" : "Internal token (required)"}
              />
              <div className="mt-2 text-xs text-slate-500">internalTokenSet: {forwarding.internalTokenSet ? "true" : "false"}</div>
            </div>
            <div className="lg:col-span-2">
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg border border-slate-200 px-5 py-3 text-sm font-semibold disabled:opacity-60"
              >
                {saving ? "Saving..." : "Save forwarding"}
              </button>
            </div>
          </form>
        </div>

        {devtoolsEnabled && (
          <div className="rounded-xl bg-white p-6 shadow-sm lg:col-span-2">
            <h2 className="text-base font-semibold text-slate-900">Devtools</h2>
            <p className="mt-2 text-sm text-slate-600">
              Emit Socket.IO events from the backend so you can test the admin UI without the OCPP VM.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <a
                href="/sessions/dev-session-1"
                target="_blank"
                rel="noreferrer"
                className="rounded-lg border border-slate-200 px-5 py-3 text-sm font-semibold"
              >
                Open dev session
              </a>
              <button
                type="button"
                onClick={emitTestAlert}
                className="rounded-lg border border-slate-200 px-5 py-3 text-sm font-semibold"
              >
                Emit test alert
              </button>
              <button
                type="button"
                onClick={emitTestSessionProgress}
                className="rounded-lg border border-slate-200 px-5 py-3 text-sm font-semibold"
              >
                Emit test session progress
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
