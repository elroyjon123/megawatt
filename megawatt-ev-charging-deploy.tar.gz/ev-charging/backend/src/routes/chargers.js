const express = require("express");
const prisma = require("../lib/prisma");

const router = express.Router();

// Get charger by ID
router.get("/:id", async (req, res) => {
  try {
    const charger = await prisma.charger.findUnique({
      where: { id: req.params.id },
      include: { sessions: true },
    });
    if (!charger) return res.status(404).json({ error: "Charger not found" });
    if (charger.status === "OFFLINE") return res.status(404).json({ error: "Charger not found" });
    res.json(charger);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
