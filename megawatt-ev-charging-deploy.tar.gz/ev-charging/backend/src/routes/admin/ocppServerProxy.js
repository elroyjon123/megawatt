const express = require("express");
const { authenticateToken, authenticateTokenOrMaintenance, requireRole } = require("../../middleware/auth");

const router = express.Router();

function baseUrl() {
  const v = process.env.OCPP_ADMIN_HTTP_BASE_URL;
  if (!v) {
    const err = new Error("OCPP_ADMIN_HTTP_BASE_URL is not configured");
    err.httpStatus = 500;
    throw err;
  }
  return String(v).replace(/\/$/, "");
}

function headers() {
  const token = process.env.OCPP_ADMIN_HTTP_TOKEN;
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function proxyJson(path, { method = "GET", body } = {}) {
  const url = `${baseUrl()}${path}`;
  const resp = await fetch(url, {
    method,
    headers: headers(),
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const text = await resp.text();
  let json;
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  if (!resp.ok) {
    const err = new Error(json?.error || json?.message || `OCPP server error (${resp.status})`);
    err.httpStatus = resp.status;
    err.payload = json;
    throw err;
  }
  return json;
}

function mustChargePointId(body) {
  const cp = body?.chargePointId || body?.ocppId;
  if (!cp) {
    const err = new Error("chargePointId is required");
    err.httpStatus = 400;
    throw err;
  }
  return String(cp);
}

// GET /api/admin/ocpp-server/connected
router.get("/connected", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const data = await proxyJson("/admin/connected");
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// GET /api/admin/ocpp-server/forwarding
router.get("/forwarding", authenticateTokenOrMaintenance, async (req, res) => {
  try {
    const data = await proxyJson("/admin/forwarding");
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/forwarding
router.post("/forwarding", authenticateTokenOrMaintenance, async (req, res) => {
  try {
    const { progressTargetUrl, alertTargetUrl, internalToken, internalBaseUrl } = req.body || {};

    if (!progressTargetUrl && !alertTargetUrl && !internalToken && !internalBaseUrl) {
      return res
        .status(400)
        .json({
          error: "Provide at least one of progressTargetUrl, alertTargetUrl, internalToken, internalBaseUrl",
        });
    }

    const body = {
      ...(progressTargetUrl ? { progressTargetUrl } : {}),
      ...(alertTargetUrl ? { alertTargetUrl } : {}),
      ...(internalToken ? { internalToken } : {}),
      ...(internalBaseUrl ? { internalBaseUrl } : {}),
    };
    const data = await proxyJson("/admin/forwarding", { method: "POST", body });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// GET /api/admin/ocpp-server/connected/:chargePointId
router.get("/connected/:chargePointId", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const data = await proxyJson(`/admin/connected/${encodeURIComponent(req.params.chargePointId)}`);
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/change-availability
router.post("/change-availability", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const { chargePointId, connectorId = 0, type } = req.body || {};
    if (!chargePointId || !type) {
      return res.status(400).json({ error: "chargePointId and type are required" });
    }
    const data = await proxyJson("/admin/change-availability", {
      method: "POST",
      body: { chargePointId, connectorId: Number(connectorId), type },
    });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/unlock-connector
router.post("/unlock-connector", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const { chargePointId, connectorId } = req.body || {};
    if (!chargePointId || connectorId == null) {
      return res.status(400).json({ error: "chargePointId and connectorId are required" });
    }
    const data = await proxyJson("/admin/unlock-connector", {
      method: "POST",
      body: { chargePointId, connectorId: Number(connectorId) },
    });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/get-configuration
router.post("/get-configuration", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const { chargePointId, key } = req.body || {};
    if (!chargePointId || !Array.isArray(key) || key.length === 0) {
      return res.status(400).json({ error: "chargePointId and key[] are required" });
    }
    const data = await proxyJson("/admin/get-configuration", {
      method: "POST",
      body: { chargePointId, key },
    });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/remote-start
// Body: { chargePointId, idTag, connectorId? }
router.post("/remote-start", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const chargePointId = mustChargePointId(req.body);
    const { idTag, connectorId = 0 } = req.body || {};
    if (!idTag) return res.status(400).json({ error: "idTag is required" });

    const data = await proxyJson("/admin/remote-start", {
      method: "POST",
      body: { chargePointId, idTag, connectorId: connectorId != null ? Number(connectorId) : 0 },
    });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/remote-stop
// Body: { chargePointId, transactionId }
router.post("/remote-stop", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const chargePointId = mustChargePointId(req.body);
    const { transactionId } = req.body || {};
    if (transactionId == null) return res.status(400).json({ error: "transactionId is required" });

    const data = await proxyJson("/admin/remote-stop", {
      method: "POST",
      body: { chargePointId, transactionId: Number(transactionId) },
    });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

// POST /api/admin/ocpp-server/reset
// Body: { chargePointId, type?: "Soft"|"Hard" }
router.post("/reset", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const chargePointId = mustChargePointId(req.body);
    const { type = "Soft" } = req.body || {};
    const data = await proxyJson("/admin/reset", {
      method: "POST",
      body: { chargePointId, type },
    });
    return res.json(data);
  } catch (error) {
    return res.status(error.httpStatus || 500).json({ error: error.message, details: error.payload });
  }
});

module.exports = router;
