const express = require("express");
const { authenticateToken, requireRole } = require("../../middleware/auth");
const prisma = require("../../lib/prisma");

const router = express.Router();

// Create station (ADMIN)
router.post("/", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const { name, address, city, latitude, longitude, openHours, photos } = req.body;
    const station = await prisma.station.create({
      data: {
        name,
        address,
        city,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        openHours,
        photos: photos || [],
      },
    });
    res.json(station);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all stations (ADMIN)
router.get("/", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const { q, isActive, page, pageSize } = req.query;

    const where = {
      ...(typeof isActive === "string" ? { isActive: isActive === "true" } : {}),
      ...(q
        ? {
            OR: [
              { name: { contains: q, mode: "insensitive" } },
              { address: { contains: q, mode: "insensitive" } },
              { city: { contains: q, mode: "insensitive" } },
            ],
          }
        : {}),
    };

    // Backward compatible: return array when no paging is specified
    if (!page && !pageSize) {
      const stations = await prisma.station.findMany({
        where,
        include: { chargers: true },
        orderBy: { createdAt: "desc" },
      });
      return res.json(stations);
    }

    const pageNum = Math.max(parseInt(page || "1", 10), 1);
    const size = Math.min(Math.max(parseInt(pageSize || "20", 10), 1), 100);
    const skip = (pageNum - 1) * size;

    const [total, items] = await Promise.all([
      prisma.station.count({ where }),
      prisma.station.findMany({
        where,
        include: { chargers: true },
        orderBy: { createdAt: "desc" },
        skip,
        take: size,
      }),
    ]);

    return res.json({ items, page: pageNum, pageSize: size, total });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get station by ID (ADMIN)
router.get("/:id", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const station = await prisma.station.findUnique({
      where: { id: req.params.id },
      include: { chargers: true },
    });
    if (!station) return res.status(404).json({ error: "Station not found" });
    res.json(station);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update station (ADMIN)
router.put("/:id", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const { name, address, city, latitude, longitude, openHours, photos } = req.body;
    const station = await prisma.station.update({
      where: { id: req.params.id },
      data: {
        name,
        address,
        city,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        openHours,
        photos,
      },
    });
    res.json(station);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deactivate station (ADMIN)
router.delete("/:id", authenticateToken, requireRole(["ADMIN", "OPERATOR"]), async (req, res) => {
  try {
    const station = await prisma.station.update({
      where: { id: req.params.id },
      data: { isActive: false },
    });
    res.json({ message: "Station deactivated", station });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
