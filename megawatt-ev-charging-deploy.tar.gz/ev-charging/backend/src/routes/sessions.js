const express = require("express");
const { authenticateToken } = require("../middleware/auth");
const prisma = require("../lib/prisma");

const router = express.Router();

// Get user's sessions
router.get("/", authenticateToken, async (req, res) => {
  try {
    const sessions = await prisma.chargingSession.findMany({
      where: { userId: req.user.id },
      include: { charger: true },
      orderBy: { startTime: "desc" },
    });
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get session detail
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const session = await prisma.chargingSession.findUnique({
      where: { id: req.params.id },
      include: { charger: true },
    });
    if (!session) return res.status(404).json({ error: "Session not found" });
    if (session.userId !== req.user.id && req.user.role !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }
    res.json(session);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
