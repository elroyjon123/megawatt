const STATUS_MAP = {
  Available: "AVAILABLE",
  Occupied: "OCCUPIED",
  Faulted: "FAULTED",
  Reserved: "RESERVED",
  Unavailable: "OFFLINE",
  Offline: "OFFLINE",
  // if bridge already sends our enum
  AVAILABLE: "AVAILABLE",
  OCCUPIED: "OCCUPIED",
  FAULTED: "FAULTED",
  OFFLINE: "OFFLINE",
  RESERVED: "RESERVED",
};

function normalizeStatus(status) {
  if (!status) return null;
  return STATUS_MAP[status] || null;
}

/**
 * @param {{ prisma: import('@prisma/client').PrismaClient, io: import('socket.io').Server }} deps
 * @param {{ ocppId: string, status?: string, timestamp?: string|Date }} evt
 */
async function syncChargerStatus({ prisma, io }, { ocppId, status, timestamp }) {
  if (!ocppId) return;
  const normalized = normalizeStatus(status);

  const charger = await prisma.charger.findUnique({ where: { ocppId } });
  if (!charger) return;

  const update = {};
  if (normalized) update.status = normalized;
  update.lastHeartbeat = timestamp ? new Date(timestamp) : new Date();

  const updated = await prisma.charger.update({
    where: { id: charger.id },
    data: update,
  });

  const payload = {
    chargerId: updated.id,
    ocppId: updated.ocppId,
    status: updated.status,
    lastHeartbeat: updated.lastHeartbeat,
  };

  // Global stream + per-charger room
  io.emit("chargers:status", payload);
  io.to(`charger:${updated.id}`).emit("charger:status", payload);
}

/**
 * @param {{ prisma: import('@prisma/client').PrismaClient, io: import('socket.io').Server }} deps
 * @param {{ ocppId: string, timestamp?: string|Date }} evt
 */
async function syncHeartbeat({ prisma, io }, { ocppId, timestamp }) {
  if (!ocppId) return;
  const charger = await prisma.charger.findUnique({ where: { ocppId } });
  if (!charger) return;

  const updated = await prisma.charger.update({
    where: { id: charger.id },
    data: { lastHeartbeat: timestamp ? new Date(timestamp) : new Date() },
  });

  const payload = {
    chargerId: updated.id,
    ocppId: updated.ocppId,
    lastHeartbeat: updated.lastHeartbeat,
  };

  io.emit("chargers:heartbeat", payload);
  io.to(`charger:${updated.id}`).emit("charger:heartbeat", payload);
}

module.exports = { syncChargerStatus, syncHeartbeat };
