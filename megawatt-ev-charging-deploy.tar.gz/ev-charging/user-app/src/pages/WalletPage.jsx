import { useEffect, useState } from "react";
import api from "../lib/api";

export default function WalletPage() {
  const [wallet, setWallet] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const resp = await api.get("/wallet/me");
        if (!cancelled) setWallet(resp.data);
      } catch (err) {
        if (!cancelled) setError(err?.response?.data?.error || err?.message || "Failed to load wallet");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="hero">
      <div className="grid" style={{ maxWidth: 760, margin: "0 auto" }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, letterSpacing: "-0.02em" }}>Wallet</h2>
          <p className="muted" style={{ marginTop: 6 }}>
            Balance is maintained by admin top-ups and session debits.
          </p>
        </div>

        {error ? <div className="error">{error}</div> : null}

        <div className="card">
          <div className="card-body">
            {loading ? (
              <p className="muted">Loading…</p>
            ) : wallet ? (
              <div className="grid">
                <div className="pill">Balance: ₱ {wallet.balancePeso}</div>
                <p className="muted">Top-ups are currently done by admins (no payment gateway in Phase 1).</p>
              </div>
            ) : (
              <p className="muted">No wallet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
