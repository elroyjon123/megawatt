import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "../lib/api";

export default function ChargerDetailPage() {
  const { id } = useParams();
  const [charger, setCharger] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const resp = await api.get(`/chargers/${id}`);
        if (!cancelled) setCharger(resp.data);
      } catch (err) {
        if (!cancelled) setError(err?.response?.data?.error || err?.message || "Failed to load charger");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [id]);

  return (
    <div className="hero">
      <div className="grid" style={{ maxWidth: 960, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, letterSpacing: "-0.02em" }}>Charger</h2>
            <p className="muted" style={{ marginTop: 6 }}>
              Live status is shown in admin; user app shows latest DB status for now.
            </p>
          </div>
          <Link className="btn" to="/stations">
            Back to stations
          </Link>
        </div>

        {error ? <div className="error">{error}</div> : null}

        <div className="card">
          <div className="card-body">
            {loading ? (
              <p className="muted">Loading…</p>
            ) : charger ? (
              <div className="grid">
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                  <div>
                    <div style={{ fontWeight: 900, fontSize: 16 }}>{charger.name}</div>
                    <div className="muted">OCPP: {charger.ocppId}</div>
                  </div>
                  <div className="pill">{charger.status}</div>
                </div>

                <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
                  <div className="card"><div className="card-body">Connector: <b>{charger.connectorType}</b></div></div>
                  <div className="card"><div className="card-body">Power: <b>{charger.powerOutputKw} kW</b></div></div>
                  <div className="card"><div className="card-body">Price: <b>₱ {charger.pricePerKwh}/kWh</b></div></div>
                </div>

                <div>
                  <div style={{ fontWeight: 900, marginBottom: 8 }}>Recent sessions (yours appear in Sessions)</div>
                  {charger.sessions?.length ? (
                    <div className="grid">
                      {charger.sessions
                        .slice()
                        .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
                        .slice(0, 5)
                        .map((s) => (
                          <div key={s.id} className="card">
                            <div className="card-body" style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                              <div>
                                <div style={{ fontWeight: 900 }}>{s.status}</div>
                                <div className="muted">Start: {new Date(s.startTime).toLocaleString()}</div>
                              </div>
                              <div style={{ textAlign: "right" }}>
                                <div className="muted">kWh: {s.energyKwh}</div>
                                <div className="muted">₱ {s.costPeso}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <p className="muted">No sessions.</p>
                  )}
                </div>
              </div>
            ) : (
              <p className="muted">Not found.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
