import { Link } from "react-router-dom";

export default function HomePage({ user }) {
  return (
    <div className="hero">
      <div className="grid grid-2">
        <div>
          <h1 className="headline">Charge smarter with Megawatt.</h1>
          <p className="subhead">
            Find nearby EV charging stations, start sessions, track costs, and manage your wallet — all in one app.
          </p>

          <div style={{ marginTop: 18, display: "flex", gap: 10, flexWrap: "wrap" }}>
            {user ? (
              <>
                <span className="pill">Logged in as {user.email}</span>
                <Link className="btn" to="/account">
                  My account
                </Link>
              </>
            ) : (
              <>
                <Link className="btn btn-primary" to="/signup">
                  Create account
                </Link>
                <Link className="btn" to="/login">
                  Log in
                </Link>
              </>
            )}
          </div>

          <div style={{ marginTop: 20, display: "flex", gap: 10, flexWrap: "wrap" }}>
            <span className="pill">Realtime charger status</span>
            <span className="pill">Wallet + vouchers</span>
            <span className="pill">Receipts + history</span>
          </div>
        </div>

        <div className="card">
          <div className="card-body">
            <h2 style={{ margin: 0, fontSize: 16, letterSpacing: "-0.02em" }}>Get started</h2>
            <p className="muted" style={{ marginTop: 6 }}>
              Sign up with email/password or use Google.
            </p>
            <div style={{ marginTop: 12 }} className="grid">
              <Link className="btn btn-primary" to="/signup">
                Sign up
              </Link>
              <Link className="btn" to="/login">
                Log in
              </Link>
              <div className="divider">or</div>
              <a className="btn btn-google" href={`${import.meta.env.VITE_API_URL}/auth/google/start`}>
                Continue with Google
              </a>
              <p className="muted">
                Note: Google login requires backend env vars (GOOGLE_CLIENT_ID/SECRET). If not set, you’ll get an error.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="footer">
        © {new Date().getFullYear()} Megawatt • EV Charging
      </div>
    </div>
  );
}
