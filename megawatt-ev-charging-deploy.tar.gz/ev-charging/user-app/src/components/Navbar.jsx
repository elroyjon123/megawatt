import { Link, useNavigate } from "react-router-dom";

export default function Navbar({ user, onLogout }) {
  const navigate = useNavigate();

  return (
    <div className="nav">
      <Link to="/" className="brand">
        <span className="brand-badge" aria-hidden="true" />
        <span>Megawatt</span>
      </Link>

      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        {user ? (
          <>
            <Link className="btn btn-link" to="/stations">
              Stations
            </Link>
            <Link className="btn btn-link" to="/wallet">
              Wallet
            </Link>
            <Link className="btn btn-link" to="/messages">
              Inbox
            </Link>
            <Link className="btn btn-link" to="/profile">
              Profile
            </Link>
            <span className="pill">{user.email}</span>
            <button
              className="btn"
              onClick={() => {
                onLogout?.();
                navigate("/");
              }}
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <Link className="btn btn-link" to="/login">
              Log in
            </Link>
            <Link className="btn btn-primary" to="/signup">
              Sign up
            </Link>
          </>
        )}
      </div>
    </div>
  );
}

