# Megawatt Mobile App (Expo Router)

This is the **React Native + Expo** mobile app scaffold described in `Megawatt_UserApp_Cline_Plan.md`.

## Requirements

- Node.js
- Expo Go (for quick device testing)
- Backend API running (dev): `http://localhost:3001`

## Environment

Copy `.env.example` → `.env`.

```bash
cd ev-charging/mobile
cp .env.example .env
```

> On a real device, `localhost` points to the phone, not your Mac.
> Use your machine LAN IP, e.g. `http://192.168.1.10:3001/api`.

## Run

```bash
cd ev-charging/mobile
npm run start
```

## What’s included (scaffold)

- Expo Router navigation
- Auth group: login/register/forgot-password (JWT)
- Tabs group: stations/search/inbox/profile (placeholders)
- Axios API client + refresh-token interceptor
- Token persistence via `expo-secure-store`
- React Query provider
