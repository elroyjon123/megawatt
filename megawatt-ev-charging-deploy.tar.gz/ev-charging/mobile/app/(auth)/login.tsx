import { useState } from "react";
import { Alert, Pressable, Text, TextInput, View } from "react-native";
import { Link, useRouter } from "expo-router";
import { useAuthStore } from "../../lib/store";

export default function LoginScreen() {
  const router = useRouter();
  const login = useAuthStore((s) => s.login);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    try {
      await login(email.trim(), password);
      router.replace("/(tabs)");
    } catch (e: any) {
      Alert.alert("Login failed", e?.response?.data?.error || e?.message || "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center", gap: 12 }}>
      <Text style={{ fontSize: 28, fontWeight: "800" }}>Megawatt</Text>
      <Text style={{ opacity: 0.7 }}>Log in to continue.</Text>

      <TextInput
        value={email}
        onChangeText={setEmail}
        placeholder="Email"
        autoCapitalize="none"
        keyboardType="email-address"
        style={{ borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 12 }}
      />
      <TextInput
        value={password}
        onChangeText={setPassword}
        placeholder="Password"
        secureTextEntry
        style={{ borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 12 }}
      />

      <Pressable
        disabled={loading}
        onPress={submit}
        style={{ backgroundColor: "#10b981", padding: 14, borderRadius: 12, alignItems: "center", opacity: loading ? 0.6 : 1 }}
      >
        <Text style={{ color: "white", fontWeight: "800" }}>{loading ? "Signing in…" : "Log in"}</Text>
      </Pressable>

      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <Link href="/(auth)/register" asChild>
          <Text style={{ color: "#0f172a", fontWeight: "700" }}>Create account</Text>
        </Link>
        <Link href="/(auth)/forgot-password" asChild>
          <Text style={{ color: "#0f172a", fontWeight: "700" }}>Forgot password?</Text>
        </Link>
      </View>
    </View>
  );
}
