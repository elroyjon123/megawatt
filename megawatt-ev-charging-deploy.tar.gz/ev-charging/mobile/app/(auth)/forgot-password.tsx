import { Text, View } from "react-native";
import { Link } from "expo-router";

export default function ForgotPasswordScreen() {
  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center", gap: 12 }}>
      <Text style={{ fontSize: 22, fontWeight: "800" }}>Forgot password</Text>
      <Text style={{ opacity: 0.7 }}>
        Phase 1 scaffold only. We’ll add email reset flow when backend supports it.
      </Text>
      <Link href="/(auth)/login" asChild>
        <Text style={{ fontWeight: "700" }}>Back to login</Text>
      </Link>
    </View>
  );
}
