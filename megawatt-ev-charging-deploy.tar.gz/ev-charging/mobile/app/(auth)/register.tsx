import { useState } from "react";
import { Alert, Pressable, Text, TextInput, View } from "react-native";
import { Link, useRouter } from "expo-router";
import { useAuthStore } from "../../lib/store";

export default function RegisterScreen() {
  const router = useRouter();
  const register = useAuthStore((s) => s.register);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    try {
      await register({ name: name.trim(), email: email.trim(), phone: phone.trim() || undefined, password });
      router.replace("/(tabs)");
    } catch (e: any) {
      Alert.alert("Register failed", e?.response?.data?.error || e?.message || "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center", gap: 12 }}>
      <Text style={{ fontSize: 22, fontWeight: "800" }}>Create account</Text>

      <TextInput
        value={name}
        onChangeText={setName}
        placeholder="Full name"
        style={{ borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 12 }}
      />
      <TextInput
        value={email}
        onChangeText={setEmail}
        placeholder="Email"
        autoCapitalize="none"
        keyboardType="email-address"
        style={{ borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 12 }}
      />
      <TextInput
        value={phone}
        onChangeText={setPhone}
        placeholder="Mobile number (optional)"
        keyboardType="phone-pad"
        style={{ borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 12 }}
      />
      <TextInput
        value={password}
        onChangeText={setPassword}
        placeholder="Password"
        secureTextEntry
        style={{ borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 12 }}
      />

      <Pressable
        disabled={loading}
        onPress={submit}
        style={{ backgroundColor: "#10b981", padding: 14, borderRadius: 12, alignItems: "center", opacity: loading ? 0.6 : 1 }}
      >
        <Text style={{ color: "white", fontWeight: "800" }}>{loading ? "Creating…" : "Sign up"}</Text>
      </Pressable>

      <Link href="/(auth)/login" asChild>
        <Text style={{ fontWeight: "700" }}>Already have an account? Log in</Text>
      </Link>
    </View>
  );
}
