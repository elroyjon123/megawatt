import { Pressable, Text, View } from "react-native";
import { useAuthStore } from "../../lib/store";

export default function ProfileTab() {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);

  return (
    <View style={{ flex: 1, padding: 20, gap: 12 }}>
      <Text style={{ fontSize: 18, fontWeight: "800" }}>Profile</Text>
      <Text style={{ opacity: 0.7 }}>{user ? user.email : "Not loaded"}</Text>

      <Pressable
        onPress={() => logout()}
        style={{ marginTop: 12, borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, padding: 14, alignItems: "center" }}
      >
        <Text style={{ fontWeight: "800" }}>Log out</Text>
      </Pressable>
    </View>
  );
}
