import { Text, View } from "react-native";

export default function InboxTab() {
  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 18, fontWeight: "800" }}>Inbox</Text>
      <Text style={{ opacity: 0.7, marginTop: 8 }}>Scaffold placeholder.</Text>
    </View>
  );
}
