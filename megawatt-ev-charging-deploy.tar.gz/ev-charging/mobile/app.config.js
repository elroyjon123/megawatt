// Expo config (runs in Node at build/start time)
// Loads .env so we can inject runtime config into `expo.extra`.
import 'dotenv/config';

export default ({ config }) => {
  return {
    ...config,
    scheme: config.scheme || 'megawatt',
    plugins: Array.from(new Set([...(config.plugins || []), 'expo-router', 'expo-secure-store'])),
    extra: {
      ...(config.extra || {}),
      apiUrl: process.env.EXPO_PUBLIC_API_URL || config.extra?.apiUrl || 'http://localhost:3001/api',
      socketUrl: process.env.EXPO_PUBLIC_SOCKET_URL || config.extra?.socketUrl || 'http://localhost:3001',
    },
  };
};
