import { api, setApiAccessToken } from "./api";
import { clearTokens, getRefreshToken, setTokens } from "./tokenStorage";

let isRefreshing = false;
let refreshPromise: Promise<string> | null = null;

export type AuthUser = {
  id: string;
  email: string;
  name: string;
  phone?: string | null;
  role: "USER" | "ADMIN" | "OPERATOR";
  createdAt: string;
};

export async function loginWithEmail(email: string, password: string) {
  const resp = await api.post("/auth/login", { email, password });
  const { accessToken, refreshToken, user } = resp.data || {};
  if (!accessToken || !refreshToken) throw new Error("Login did not return tokens");
  await setTokens({ accessToken, refreshToken });
  setApiAccessToken(accessToken);
  return { accessToken, refreshToken, user } as { accessToken: string; refreshToken: string; user: AuthUser };
}

export async function registerWithEmail(input: { name: string; email: string; phone?: string; password: string }) {
  const resp = await api.post("/auth/register", input);
  const { accessToken, refreshToken, user } = resp.data || {};
  if (!accessToken || !refreshToken) throw new Error("Register did not return tokens");
  await setTokens({ accessToken, refreshToken });
  setApiAccessToken(accessToken);
  return { accessToken, refreshToken, user } as { accessToken: string; refreshToken: string; user: AuthUser };
}

export async function logout() {
  try {
    await api.post("/auth/logout");
  } catch {
    // ignore
  }
  await clearTokens();
  setApiAccessToken(null);
}

async function refreshAccessToken() {
  const refreshToken = await getRefreshToken();
  if (!refreshToken) throw new Error("No refresh token");
  const resp = await api.post("/auth/refresh", { refreshToken });
  const newAccessToken = resp.data?.accessToken;
  if (!newAccessToken) throw new Error("Refresh did not return accessToken");
  // keep same refresh token
  await setTokens({ accessToken: newAccessToken, refreshToken });
  setApiAccessToken(newAccessToken);
  return newAccessToken as string;
}

/**
 * Adds a single response interceptor that refreshes the access token on 401/403.
 */
export function configureAuthInterceptor({ onLogout }: { onLogout?: () => void } = {}) {
  api.interceptors.response.use(
    (r) => r,
    async (error) => {
      const original = error.config;
      const status = error.response?.status;

      if (!original || original._retry) return Promise.reject(error);
      if (status !== 401 && status !== 403) return Promise.reject(error);

      original._retry = true;
      try {
        if (!isRefreshing) {
          isRefreshing = true;
          refreshPromise = refreshAccessToken().finally(() => {
            isRefreshing = false;
          });
        }
        await refreshPromise;
        return api(original);
      } catch (e) {
        await logout();
        onLogout?.();
        return Promise.reject(e);
      }
    }
  );
}
