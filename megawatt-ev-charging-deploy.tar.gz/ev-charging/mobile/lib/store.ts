import { create } from "zustand";
import { api, setApiAccessToken } from "./api";
import { configureAuthInterceptor, loginWithEmail, logout as logoutImpl, registerWithEmail, type AuthUser } from "./auth";
import { getAccessToken } from "./tokenStorage";

type AuthState = {
  booted: boolean;
  accessToken: string | null;
  user: AuthUser | null;
  bootstrap: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (input: { name: string; email: string; phone?: string; password: string }) => Promise<void>;
  logout: () => Promise<void>;
  refreshMe: () => Promise<void>;
};

export const useAuthStore = create<AuthState>((set, get) => ({
  booted: false,
  accessToken: null,
  user: null,

  bootstrap: async () => {
    // set up refresh interceptor once
    configureAuthInterceptor({
      onLogout: () => set({ accessToken: null, user: null }),
    });

    const accessToken = await getAccessToken();
    setApiAccessToken(accessToken);
    set({ accessToken: accessToken || null });

    if (accessToken) {
      await get().refreshMe().catch(() => {
        // ignore
      });
    }

    set({ booted: true });
  },

  refreshMe: async () => {
    const resp = await api.get("/auth/me");
    set({ user: resp.data });
  },

  login: async (email, password) => {
    const { accessToken, user } = await loginWithEmail(email, password);
    set({ accessToken, user });
  },

  register: async (input) => {
    const { accessToken, user } = await registerWithEmail(input);
    set({ accessToken, user });
  },

  logout: async () => {
    await logoutImpl();
    set({ accessToken: null, user: null });
  },
}));
