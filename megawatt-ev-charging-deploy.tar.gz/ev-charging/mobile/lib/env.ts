import Constants from "expo-constants";

type ExpoConfigExtra = {
  apiUrl?: string;
  socketUrl?: string;
};

function getExtra(): ExpoConfigExtra {
  const extra = (Constants.expoConfig?.extra || Constants.manifest?.extra || {}) as any;
  return extra as ExpoConfigExtra;
}

const extra = getExtra();

// Prefer app.json extra values. Fall back to localhost for simulator/web.
export const API_URL = extra.apiUrl || "http://localhost:3001/api";
export const SOCKET_URL = extra.socketUrl || "http://localhost:3001";
